import { getTranslations, setRequestLocale } from "next-intl/server";
import { getLevelInfo } from "@/lib/levels";
import { levelIcon } from "@/lib/category-style";
import { resolveContext } from "@/lib/dev-family";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { EmptyState } from "@/components/ui/EmptyState";
import { Collapsible } from "@/components/ui/Collapsible";
import { ageFromDob } from "@/lib/age";
import { Link } from "@/lib/i18n/routing";
import { createChild, uploadAvatar, setPin, revokeAssignment, updateChildBirthday } from "./actions";
import { CoinIcon } from "@/components/ui/CoinIcon";

const PILL = "inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-xs font-medium transition-colors";
const TOGGLE_PILL = "cursor-pointer select-none bg-stone-100 text-stone-600 ring-amber-400 hover:bg-stone-200";
const PANEL = "hidden flex-wrap items-center gap-2 rounded-xl bg-stone-50 p-3";

export default async function KidsPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ sent?: string }>;
}) {
  const { locale } = await params;
  const { sent } = await searchParams;
  const [sentTasks, sentAssignments, sentRewards] = (sent ?? "").split(".").map(Number);
  setRequestLocale(locale);
  const t = await getTranslations();
  const { familyId, supabase } = await resolveContext();

  const q = supabase.from("children").select("id, name, grade, avatar_url, preferred_language, lifetime_stars, current_dream_reward_id, date_of_birth").eq("family_id", familyId);
  const { data: children } = await q.order("created_at", { ascending: true });

  // Fetch balances, streaks, dream rewards, assigned tasks per child
  const childDetails = await Promise.all(
    (children ?? []).map(async (c) => {
      const [balResult, streakResult, dreamResult, assignResult] = await Promise.all([
        supabase.from("child_balances").select("coin_balance, star_balance").eq("child_id", c.id).maybeSingle(),
        supabase.from("child_streaks").select("current_streak, longest_streak").eq("child_id", c.id).maybeSingle(),
        c.current_dream_reward_id
          ? supabase.from("rewards").select("name, coin_cost").eq("id", c.current_dream_reward_id).single()
          : Promise.resolve({ data: null }),
        supabase
          .from("task_assignments")
          .select("id, status, due_date, task:tasks(name, coin_reward, star_reward)")
          .eq("child_id", c.id)
          .in("status", ["todo", "submitted", "rejected"])
          .order("created_at", { ascending: false }),
      ]);
      return {
        child: c,
        coin: balResult.data?.coin_balance ?? 0,
        star: balResult.data?.star_balance ?? 0,
        streak: streakResult.data?.current_streak ?? 0,
        longestStreak: streakResult.data?.longest_streak ?? 0,
        dreamReward: dreamResult.data,
        assignments: assignResult.data ?? [],
      };
    }),
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-stone-800">👧 {t("parent.kids")}</h1>
      </div>

      {sent && !Number.isNaN(sentRewards) && (
        <Card className="border-emerald-200 bg-emerald-50 text-sm text-emerald-700">
          🎁 {t("kids.agePackSent", { tasks: sentTasks, assignments: sentAssignments, rewards: sentRewards })}
        </Card>
      )}

      {/* Add child — collapsible */}
      <Card>
        <Collapsible
          trigger={
            <span className="text-sm font-semibold text-stone-700">+ {t("kids.addChild")}</span>
          }
        >
          <form action={createChild} className="grid gap-3 sm:grid-cols-2">
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-stone-500">{t("kids.name")}</span>
              <input name="name" required className="h-11 rounded-xl border border-stone-300 px-3 text-sm" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-stone-500">{t("kids.grade")}</span>
              <input name="grade" type="number" min="1" max="12" className="h-11 rounded-xl border border-stone-300 px-3 text-sm" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-stone-500">{t("kids.birthday")}</span>
              <input name="date_of_birth" type="date" className="h-11 rounded-xl border border-stone-300 px-3 text-sm" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-stone-500">{t("kids.language")}</span>
              <select name="preferred_language" defaultValue="en" className="h-11 rounded-xl border border-stone-300 px-3 text-sm">
                <option value="en">English</option>
                <option value="vi">Tiếng Việt</option>
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium text-stone-500">🔐 {t("kids.pin")}</span>
              <input name="pin" inputMode="numeric" pattern="\d{6}" maxLength={6} minLength={6} required
                className="h-11 rounded-xl border border-stone-300 px-3 text-sm" placeholder="••••••" />
            </label>
            <div className="sm:col-span-2">
              <Button type="submit">{t("kids.addChild")}</Button>
            </div>
          </form>
        </Collapsible>
      </Card>

      {/* No children state */}
      {(!children || children.length === 0) && (
        <Card className="border-amber-200 bg-amber-50">
          <EmptyState
            icon="👧"
            title={t("parent.noKidsYet")}
            description={t("parent.addKidsHint")}
          />
        </Card>
      )}

      {/* Child profile cards */}
      <div className="grid gap-4 sm:grid-cols-2">
        {childDetails.map(({ child: c, coin, star, streak, longestStreak, dreamReward, assignments }) => {
          const level = getLevelInfo(c.lifetime_stars ?? 0);
          const levelTitle = locale === "vi" ? level.title_vi : level.title_en;
          const lvIcon = levelIcon(level.level);
          const childAge = ageFromDob(c.date_of_birth);
          return (
            <Card key={c.id} className="space-y-4">
              {/* Header */}
              <div className="flex items-center gap-3">
                {c.avatar_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.avatar_url} alt={c.name} className="h-14 w-14 rounded-full object-cover ring-2 ring-amber-200" />
                ) : (
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 to-orange-400 text-lg font-bold text-white ring-2 ring-amber-200">
                    {c.name.slice(0, 1)}
                  </div>
                )}
                <div className="flex-1">
                  <div className="text-lg font-bold text-stone-800">
                    {c.name}
                    {childAge != null && (
                      <span className="ml-1.5 text-sm font-normal text-stone-400">
                        · {t("kids.age", { age: childAge })}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-stone-500">
                    {c.grade != null ? `${t("kids.gradeLabel", { grade: c.grade })} · ` : ""}
                    {c.preferred_language === "vi" ? "Tiếng Việt" : "English"}
                  </div>
                  <div className="mt-0.5 text-xs text-indigo-500">{lvIcon} Lv.{level.level} {levelTitle}</div>
                </div>
              </div>

              {/* Stat chips */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700"><CoinIcon /> {coin}</span>
                <span className="rounded-full bg-purple-100 px-2.5 py-1 text-xs font-semibold text-purple-700">⭐ {star}</span>
                {streak > 0 && (
                  <span className="rounded-full bg-orange-100 px-2.5 py-1 text-xs font-semibold text-orange-700">🔥 {streak}</span>
                )}
              </div>

              {/* Level progress */}
              {level.nextLevelStars && (
                <div>
                  <ProgressBar
                    value={c.lifetime_stars - level.minStars}
                    max={level.nextLevelStars - level.minStars}
                    color="indigo"
                    size="sm"
                  />
                  <div className="mt-0.5 text-[11px] text-stone-400">
                    {c.lifetime_stars} / {level.nextLevelStars} ⭐ → Lv.{level.level + 1}
                  </div>
                </div>
              )}

              {/* Dream reward */}
              {dreamReward && (
                <div className="rounded-xl bg-purple-50 p-3">
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium text-purple-700">🌈 {dreamReward.name}</span>
                    <span className="font-semibold text-purple-700">
                      {Math.min(100, Math.round((coin / dreamReward.coin_cost) * 100))}%
                    </span>
                  </div>
                  <ProgressBar value={coin} max={dreamReward.coin_cost} color="purple" size="sm" />
                </div>
              )}

              {/* Assigned tasks */}
              {assignments.length > 0 && (
                <div className="border-t border-stone-100 pt-3">
                  <Collapsible
                    trigger={
                      <span className="rounded-lg bg-indigo-50 px-3 py-1.5 text-xs font-medium text-indigo-600 hover:bg-indigo-100">
                        📋 {t("kids.assignedTasks", { count: assignments.length })}
                      </span>
                    }
                  >
                    <ul className="mt-2 space-y-1.5">
                      {assignments.map((a) => {
                        const task = Array.isArray(a.task) ? a.task[0] : a.task;
                        const statusColor =
                          a.status === "submitted" ? "text-amber-600 bg-amber-50" :
                          a.status === "rejected"  ? "text-red-500 bg-red-50" :
                          "text-stone-500 bg-stone-100";
                        const statusLabel =
                          a.status === "submitted" ? t("kids.statusSubmitted") :
                          a.status === "rejected"  ? t("kids.statusRejected") : t("kids.statusTodo");
                        return (
                          <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg border border-stone-100 bg-stone-50 px-3 py-2">
                            <div className="min-w-0 flex-1">
                              <div className="truncate text-xs font-medium text-stone-800">{task?.name}</div>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className={`rounded-full px-1.5 py-0.5 text-[11px] font-semibold ${statusColor}`}>{statusLabel}</span>
                                {task?.coin_reward ? <span className="text-[11px] text-amber-600"><CoinIcon /> {task.coin_reward}</span> : null}
                                {a.due_date && <span className="text-[11px] text-stone-400">{a.due_date}</span>}
                              </div>
                            </div>
                            {a.status !== "submitted" && (
                              <form action={revokeAssignment}>
                                <input type="hidden" name="assignment_id" value={a.id} />
                                <button
                                  type="submit"
                                  title={t("kids.revokeAssignment")}
                                  aria-label={t("kids.revokeAssignment")}
                                  className="rounded-full p-1 text-stone-300 hover:bg-red-50 hover:text-red-400 transition-colors"
                                >
                                  ✕
                                </button>
                              </form>
                            )}
                          </li>
                        );
                      })}
                    </ul>
                  </Collapsible>
                </div>
              )}

              {/* Actions — a row of equal pills; each toggle opens its form on its own line below */}
              <div className="group/actions space-y-3 border-t border-stone-100 pt-3">
                <div className="flex flex-wrap gap-2">
                  <Link href={`/kids/${c.id}/age-pack`} className={`${PILL} bg-amber-100 text-amber-700 hover:bg-amber-200`}>
                    🎁 {t("kids.agePack")}
                  </Link>
                  <input id={`avatar-${c.id}`} type="checkbox" className="avatar-toggle sr-only" />
                  <label
                    htmlFor={`avatar-${c.id}`}
                    className={`${PILL} ${TOGGLE_PILL} group-has-[.avatar-toggle:checked]/actions:bg-stone-200 group-has-[.avatar-toggle:checked]/actions:text-stone-800 group-has-[.avatar-toggle:focus-visible]/actions:ring-2`}
                  >
                    📷 {t("kids.changeAvatar")}
                  </label>
                  <input id={`pin-${c.id}`} type="checkbox" className="pin-toggle sr-only" />
                  <label
                    htmlFor={`pin-${c.id}`}
                    className={`${PILL} ${TOGGLE_PILL} group-has-[.pin-toggle:checked]/actions:bg-stone-200 group-has-[.pin-toggle:checked]/actions:text-stone-800 group-has-[.pin-toggle:focus-visible]/actions:ring-2`}
                  >
                    🔐 {t("kids.changePin")}
                  </label>
                  <input id={`birthday-${c.id}`} type="checkbox" className="birthday-toggle sr-only" />
                  <label
                    htmlFor={`birthday-${c.id}`}
                    className={`${PILL} ${TOGGLE_PILL} group-has-[.birthday-toggle:checked]/actions:bg-stone-200 group-has-[.birthday-toggle:checked]/actions:text-stone-800 group-has-[.birthday-toggle:focus-visible]/actions:ring-2`}
                  >
                    🎂 {t("kids.birthday")}
                  </label>
                </div>

                <form action={uploadAvatar} className={`${PANEL} group-has-[.avatar-toggle:checked]/actions:flex`}>
                  <input type="hidden" name="child_id" value={c.id} />
                  <input type="file" name="avatar" accept="image/*" required className="min-w-0 flex-1 text-xs" />
                  <Button type="submit" size="sm" variant="secondary">{t("common.save")}</Button>
                </form>

                <form action={setPin} className={`${PANEL} group-has-[.pin-toggle:checked]/actions:flex`}>
                  <input type="hidden" name="child_id" value={c.id} />
                  <input name="pin" inputMode="numeric" pattern="\d{6}" maxLength={6} minLength={6} required
                    placeholder="••••••" className="h-9 w-28 rounded-xl border border-stone-300 bg-white px-3 text-sm" />
                  <Button type="submit" size="sm" variant="secondary">{t("kids.setPin")}</Button>
                </form>

                <form action={updateChildBirthday} className={`${PANEL} group-has-[.birthday-toggle:checked]/actions:flex`}>
                  <input type="hidden" name="child_id" value={c.id} />
                  <input name="date_of_birth" type="date" defaultValue={c.date_of_birth ?? ""}
                    className="h-9 rounded-xl border border-stone-300 bg-white px-3 text-sm" />
                  <Button type="submit" size="sm" variant="secondary">{t("common.save")}</Button>
                </form>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
